package guiCalculator;

import javax.swing.*;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * The type Calculator.
 */
public class Calculator extends JFrame {
    //main JPanel
    private JPanel contentPane;
    //add buttons
    private JButton btnOne;
    private JButton btnTwo;
    private JButton btnThree;
    private JButton btnFour;
    private JButton btnFive;
    private JButton btnSix;
    private JButton btnSeven;
    private JButton btnEight;
    private JButton btnNine;
    private JButton btnZero;
    private JButton btnDot;
    //calculate button
    private JButton btnEquals;
    //operator buttons
    private JButton btnFractionOfOne;
    private JButton btnSubtraction;
    private JButton btnAddition;
    private JButton btnDelete;
    private JButton btnPow;
    private JButton btnClear;
    private JButton btnClearEntry;
    private JButton btnDivision;
    private JButton btnMultiplication;
    private JButton btnSqrt;
    private JButton btnPercent;
    //GUI buttons
    private JButton btnToggleHistory;
    //Text panes
    private JTextPane txtPaneCurrentNumber;
    private JTextPane txtPaneHistory;
    private JTextPane txtPaneOutput;
    //vars for actual calculating
    private String currentNumber = "";
    private String previousNumber = "";
    private String operator = "";
    private String lastResult = "";
    //result ArrayList for "History"
    private ArrayList<String> results = new ArrayList<String>();

    /**
     * Instantiates a new Calculator.
     */
    public Calculator() {
        setContentPane(contentPane);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        initTxtPanes();

        /* Add Keyboard listener */

        /* Quit on ESC key */
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        /* add delete last number on backspace */
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteLastNumber();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_BACK_SPACE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        /* add calculate on enter */
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calculate();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        /* add calculate on equals */
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calculate();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_EQUALS, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        /* add multiplication on "*" press */
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                operatorClick("*");
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_MULTIPLY, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        /* add addition on "+" press */
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                operatorClick("+");
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ADD, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        /* add subtraction on "-" press */
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                operatorClick("-");
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_SUBTRACT, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        /* add division on "/" press */
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                operatorClick("/");
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_DIVIDE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        /* add "." special number click */
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                numberClick(".");
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_DECIMAL, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        /* adding number 0-9 to keyboard row */
        int[] numberKeys = {KeyEvent.VK_0, KeyEvent.VK_1, KeyEvent.VK_2, KeyEvent.VK_3, KeyEvent.VK_4, KeyEvent.VK_5, KeyEvent.VK_6, KeyEvent.VK_7, KeyEvent.VK_8, KeyEvent.VK_9};
        //count var
        int count = 0;
        for (int key : numberKeys) {
            String temp = Integer.toString(count);
            count++;
            contentPane.registerKeyboardAction(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    numberClick(temp);
                }
            }, KeyStroke.getKeyStroke(key, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }

        count = 0; //reset count

        /* adding number 0-9 to keyboard numpad */
        int[] numberNumpadKeys = {KeyEvent.VK_NUMPAD0, KeyEvent.VK_NUMPAD1, KeyEvent.VK_NUMPAD2, KeyEvent.VK_NUMPAD3, KeyEvent.VK_NUMPAD4, KeyEvent.VK_NUMPAD5, KeyEvent.VK_NUMPAD6, KeyEvent.VK_NUMPAD7, KeyEvent.VK_NUMPAD8, KeyEvent.VK_NUMPAD9};
        for (int key : numberNumpadKeys) {
            String temp = Integer.toString(count);
            count++;
            contentPane.registerKeyboardAction(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    numberClick(temp);
                }
            }, KeyStroke.getKeyStroke(key, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }

        /* Add Action listener */
        ActionListener btnNumberListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() instanceof JButton) {
                    numberClick(e.getActionCommand());
                }
            }
        };

        JButton[] numberButtons = {btnZero, btnOne, btnTwo, btnThree, btnFour, btnFive, btnSix, btnSeven, btnEight, btnNine, btnDot};
        setListener(btnNumberListener, numberButtons);

        ActionListener btnOperatorListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() instanceof JButton) {
                    operatorClick(e.getActionCommand());
                }
            }
        };

        JButton[] operatorButtons = {btnAddition, btnSubtraction, btnMultiplication, btnDivision, btnPercent};
        setListener(btnOperatorListener, operatorButtons);

        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteLastNumber();
            }
        });

        btnEquals.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculate();
            }
        });

        btnClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clear();
            }
        });

        btnClearEntry.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearEntry();
            }
        });

        btnFractionOfOne.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fractionOfOne();
            }
        });

        btnSqrt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                squareRoot();
            }
        });

        btnPow.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pow();
            }
        });
    }

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     * @throws ClassNotFoundException          the class not found exception
     * @throws UnsupportedLookAndFeelException the unsupported look and feel exception
     * @throws InstantiationException          the instantiation exception
     * @throws IllegalAccessException          the illegal access exception
     */
    public static void main(String[] args) throws ClassNotFoundException, UnsupportedLookAndFeelException, InstantiationException, IllegalAccessException {
        //UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); //ugly-mode for windows standard view (in its not set, it should use the OS Java default)
        Calculator frame = new Calculator();
        frame.pack();
        frame.setVisible(true);
        frame.setSize(600, 400);
    }

    private void initTxtPanes() {
        //set style for right alignment
        SimpleAttributeSet attributes = new SimpleAttributeSet();
        StyleConstants.setAlignment(attributes, StyleConstants.ALIGN_RIGHT);
        StyleConstants.setFontFamily(attributes, "Default");
        StyleConstants.setForeground(attributes, Color.white);
        txtPaneCurrentNumber.setParagraphAttributes(attributes, true);
        txtPaneOutput.setParagraphAttributes(attributes, true);
        txtPaneHistory.setParagraphAttributes(attributes, true);
    }

    /***
     * exits the application
     */
    private void onCancel() {
        dispose();
    }

    /***
     * adds the clicked number/dot to the output label
     * @param number ActionEvent.actionCommand number or dot
     */
    private void numberClick(String number) {
        String currentNumber = getCurrentNumber();
        if (!number.equals(".") || !currentNumber.contains(".")) {
            updateCurrentNumber(currentNumber + number);
        }
    }

    /***
     * Sets the operator and moves the "current" number into the "previous" number
     * and clears the "current" number
     * @param operator ActionEvent.actionCommand operator sign
     */
    private void operatorClick(String operator) {
        String currentNumber = getCurrentNumber();
        String lastResult = getLastResult();
        if (currentNumber.equals("") && lastResult.equals("")) {
            return;
        } else if (currentNumber.equals("") && !lastResult.equals("")) {
            currentNumber = lastResult;
        }

        setPreviousNumber(currentNumber);
        setOperator(operator);
        updateCurrentNumber("");
        updateOutput();
    }

    /***
     * updates the GUI currentNumber label
     * @param number updates the current number
     */
    private void updateCurrentNumber(String number) {
        setCurrentNumber(number);
        txtPaneCurrentNumber.setText(number);
    }

    /***
     * updates the GUI output label
     */
    private void updateOutput() {
        txtPaneOutput.setText(getOutput());
    }

    /***
     * updates the history text panel and formats the string
     */
    private void updateHistory() {
        String text = getResults().toString().replaceAll(",", "\n").replaceAll("\\[|\\]", " ");
        txtPaneHistory.setText(text);
    }

    /***
     * deletes last number/dot from output label
     */
    private void deleteLastNumber() {
        String number = getCurrentNumber();
        if (number.length() > 1) {
            number = number.substring(0, number.length() - 1);
        } else {
            number = "";
        }
        updateCurrentNumber(number);
    }

    /***
     * resets all data and updates the frame
     */
    private void clear() {
        setPreviousNumber("");
        setOperator("");
        setLastResult("");
        setResults(new ArrayList<>());
        updateCurrentNumber("");
        updateOutput();
        updateHistory();
    }

    /***
     * resets the current number
     */
    private void clearEntry() {
        updateCurrentNumber("");
    }

    /***
     * returns the calculation string
     * @return String
     */
    private String getOutput() {
        return getPreviousNumber() + getOperator() + getCurrentNumber();
    }

    /***
     * calculates the result depending on previous/current number and operator
     */
    private void calculate() {
        updateOutput();
        String previousNumber = getPreviousNumber();
        String currentNumber = getCurrentNumber();
        String operator = getOperator();

        if (previousNumber.equals("") || currentNumber.equals("")) {
            return;
        }


        if (currentNumber.startsWith("0") && currentNumber.matches("[^1-9]+")) {
            JOptionPane.showMessageDialog(null, "Can't divide by Zero");
            return;
        }

        double number1 = Double.parseDouble(previousNumber);
        double number2 = Double.parseDouble(currentNumber);

        setPreviousNumber(currentNumber);
        switch (operator) {
            case "+" -> updateCurrentNumber(Double.toString(number1 + number2));
            case "-" -> updateCurrentNumber(Double.toString(number1 - number2));
            case "*" -> updateCurrentNumber(Double.toString(number1 * number2));
            case "/" -> updateCurrentNumber(Double.toString(number1 / number2));
            case "%" -> updateCurrentNumber((number1 / number2) * 100 + "%");
            default -> updateCurrentNumber("");
        }
        setLastResult(getCurrentNumber());
        generateResult(previousNumber, currentNumber, operator);
        setCurrentNumber("");
        updateHistory();
    }

    private void fractionOfOne() {
        String currentNumber = txtPaneCurrentNumber.getText();
        if (currentNumber.equals("0") || currentNumber.equals("0.0") || currentNumber.equals("")) {
            return;
        }
        double number = Double.parseDouble(currentNumber);
        updateCurrentNumber(Double.toString(1 / number));
    }

    /***
     * calculates the square root
     */
    private void squareRoot() {
        double number = Double.parseDouble(txtPaneCurrentNumber.getText());
        updateCurrentNumber(Double.toString(Math.sqrt(number)));
    }

    /**
     * calculates to square
     */
    private void pow() {
        double number = Double.parseDouble(txtPaneCurrentNumber.getText());
        updateCurrentNumber(Double.toString(Math.pow(number, 2)));
    }

    /***
     * Sets the listener given for a array of JButtons
     * @param btnOperatorListener ActionListener instance
     * @param operatorButtons Array of JButtons
     */
    private void setListener(ActionListener btnOperatorListener, JButton[] operatorButtons) {
        for (JButton jButton : operatorButtons) {
            jButton.addActionListener(btnOperatorListener);
        }
    }

    /***
     * generates a result string for displaying in history
     * @param previousNumber first number
     * @param currentNumber second number
     * @param operator mathematical operator
     */
    private void generateResult(String previousNumber, String currentNumber, String operator) {
        if (getResults().size() >= 15) {
            getResults().remove(0);
        }
        String result = previousNumber + operator + currentNumber + " = " + getCurrentNumber();
        getResults().add(result);
    }

    /**
     * !!! disabled !!!
     * Toggle history.
     */
    public void toggleHistory() {
        txtPaneHistory.setVisible(!txtPaneHistory.isVisible());
    }

    /* Getters and Setters */

    /**
     * Gets current number.
     *
     * @return the current number
     */
    public String getCurrentNumber() {
        return currentNumber;
    }

    /**
     * Sets current number.
     *
     * @param currentNumber the current number
     */
    public void setCurrentNumber(String currentNumber) {
        this.currentNumber = currentNumber;
    }

    /**
     * Gets previous number.
     *
     * @return the previous number
     */
    public String getPreviousNumber() {
        return previousNumber;
    }

    /**
     * Sets previous number.
     *
     * @param previousNumber the previous number
     */
    public void setPreviousNumber(String previousNumber) {
        this.previousNumber = previousNumber;
    }

    /**
     * Gets operator.
     *
     * @return the operator
     */
    public String getOperator() {
        return operator;
    }

    /**
     * Sets operator.
     *
     * @param operator the operator
     */
    public void setOperator(String operator) {
        this.operator = operator;
    }

    /**
     * Gets results.
     *
     * @return the results
     */
    public ArrayList<String> getResults() {
        return results;
    }

    /**
     * Sets results.
     *
     * @param results the results
     */
    public void setResults(ArrayList<String> results) {
        this.results = results;
    }

    /**
     * Gets last result.
     *
     * @return the last result
     */
    public String getLastResult() {
        return lastResult;
    }

    /**
     * Sets last result.
     *
     * @param lastResult the last result
     */
    public void setLastResult(String lastResult) {
        this.lastResult = lastResult;
    }

}
